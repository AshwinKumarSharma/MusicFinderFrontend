import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Music } from "lucide-react";
import Header from "@/components/header";
import SearchSection from "@/components/search-section";
import SearchResults from "@/components/search-results";
import VirtualDJPlayer from "@/components/virtual-dj-player";
import { Track, SearchResponse } from "@/lib/types";
import { apiRequest } from "@/lib/queryClient";
import { Button } from "@/components/ui/button";

export default function Home() {
  const [searchQuery, setSearchQuery] = useState("");
  const [currentTrack, setCurrentTrack] = useState<Track | null>(null);
  const [hasSearched, setHasSearched] = useState(false);

  const {
    data: searchResults,
    isLoading,
    error,
  } = useQuery<SearchResponse>({
    queryKey: [`/api/search?q=${encodeURIComponent(searchQuery)}`],
    enabled: !!searchQuery,
  });

  const saveSearchMutation = useMutation({
    mutationFn: async (query: string) => {
      const response = await apiRequest("POST", "/api/search-history", {
        query,
      });
      return response.json();
    },
  });

  console.log(searchResults);

  const handleSearch = (query: string) => {
    setSearchQuery(query);
    setHasSearched(true);
    saveSearchMutation.mutate(query);
  };

  const handlePlayTrack = (track: Track) => {
    setCurrentTrack(track);
  };

  const showEmptyState = !hasSearched && !searchQuery;
  const showResults = hasSearched || isLoading || error;

  return (
    <div
      className="min-h-screen"
      style={{ backgroundColor: "var(--music-dark)" }}
    >
      <Header />

      <main className="max-w-6xl mx-auto px-4 py-8 pb-32">
        <SearchSection onSearch={handleSearch} isLoading={isLoading} />

        {showResults && (
          <SearchResults
            results={searchResults?.results || []}
            isLoading={isLoading}
            error={error instanceof Error ? error.message : null}
            onPlay={handlePlayTrack}
          />
        )}

        {showEmptyState && (
          <section className="text-center py-16">
            <div className="max-w-md mx-auto">
              <div className="w-24 h-24 gradient-bg rounded-full flex items-center justify-center mx-auto mb-6">
                <Music className="text-white text-2xl" size={32} />
              </div>
              <h3 className="text-xl font-semibold mb-3">
                Start Your Musical Journey
              </h3>
              <p className="mb-6" style={{ color: "var(--music-light-gray)" }}>
                Search for your favorite songs and artists to begin listening
              </p>
              <Button
                className="gradient-bg px-6 py-3 rounded-xl text-white font-medium hover:scale-105 transition-transform duration-200"
                onClick={() => document.querySelector("input")?.focus()}
              >
                Search Music
              </Button>
            </div>
          </section>
        )}
      </main>

      <VirtualDJPlayer
        currentTrack={currentTrack}
        isVisible={!!currentTrack}
        onTrackChange={setCurrentTrack}
      />
    </div>
  );
}
